const env = {   
    SECRET_TOKEN: "Pest123",
    DB_CONNECTION_URL:"mongodb://pestpatrol:pest12345@ac-dqbhjfs-shard-00-00.9zo8ck5.mongodb.net:27017,ac-dqbhjfs-shard-00-01.9zo8ck5.mongodb.net:27017,ac-dqbhjfs-shard-00-02.9zo8ck5.mongodb.net:27017/?ssl=true&replicaSet=atlas-7n9anp-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0"
}
module.exports = env;
