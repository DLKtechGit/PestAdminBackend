const env = {   
    SECRET_TOKEN: "Pest123",
    DB_CONNECTION_URL:"mongodb+srv://pestpatrol:pestpatrol123@cluster0.9zo8ck5.mongodb.net/"
}
module.exports = env;
   