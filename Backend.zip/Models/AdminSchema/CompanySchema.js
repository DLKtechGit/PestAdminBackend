const mongoose = require('mongoose');

const Customer = new mongoose.Schema({
    firstName: {
        type: String,
        // required: true
    },
    lastName: {
        type: String,
        // required: true
    },
    name: {
        type: String,
        // required: true
    },
    email: {
        type: String,
        unique: true,
        // required: true
    },
    address: {
        type: String,
        // required: true
    },
    country: {
        type: String,
        // required: true
    },
    state: {
        type: String,
        // required: true
    },
    city: {
        type: String,
        // required: true
    },
    phoneNumber: {
        type: String,
        unique: true,
        // required: true,
    },
    deleted: {
        type: Boolean,
        default: false
    },
    password: {
        type: String,
        // required: true
    },
    confirmpassword: {
        type: String,
        // required: true
    },
    registered: {
        type: Boolean,
        default: false
    },
    role: {
        type: String,
    },
    tasks: [{
        serviceName: {
            type: String,
            // required: true
        },
        startDate: {
            type: String,
            // required: true
        },
        endtime: {
            type: String,
            // required: true
        },
        starttime: {
            type: String,
            // required: true
        },
        description: {
            type: String,
            // required: true
        },
        status: {
            type: String,
        },
        assignedTo: [
            {
                users: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'Technician'
                },
                firstName: {
                    type: String,
                    ref: 'Technician'
                },
                lastName: {
                    type: String,
                    ref: 'Technician'
                },
                phoneNumber: {
                    type: String,
                    ref: 'Technician'
                },
                email: {
                    type: String,
                    ref: 'Technician'
                },
                address: {
                    type: String,
                    ref: 'Technician'
                },
                role: {
                    type: String,
                    ref: 'Technician'
                }
            }
        ],
        assignedFrom: [
            {
                users: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: 'Customer'
                },
                name: {
                    type: String,
                    ref: 'Customer'
                },
                lastName: {
                    type: String,
                    ref: 'Customer'
                },
                phoneNumber: {
                    type: String,
                    ref: 'Customer'
                },
                email: {
                    type: String,
                    ref: 'Customer'
                },
                address: {
                    type: String,
                    ref: 'Customer'
                },
                country: {
                    type: String,
                    ref: 'Customer'
                },
                state: {
                    type: String,
                    ref: 'Customer'
                },
                city: {
                    type: String,
                    ref: 'Customer'
                },
                role: {
                    type: String,
                    ref: 'Customer'
                }
            }
        ],
    }],
    created_date: Date,
}, { minimize: false }); // Set minimize to false to store empty arrays

const CompanyModels = mongoose.model("Customer", Customer);
module.exports = CompanyModels;
